﻿using System;

namespace Practica3
{
    class Program
    {
        static void Main(string[] args)
        {
            int queTriar;
            Console.WriteLine("Exercici a provar? 1, 2, 3 ,4, 5");
            queTriar = Convert.ToInt32(Console.ReadLine());
            switch (queTriar)
            {
                case 1:
                    // Demanar a l'usuari que introdueixi un número
                    Console.WriteLine("Introdueix un número enter: ");
                    int numero = Convert.ToInt32(Console.ReadLine());

                    // Inicialitzar la suma
                    int suma = 0;
                    if (numero >= 13)
                    {
                        // Suma tots els números desde 13 fins al número introduït
                        for (int i = 13; i <= numero; i++)
                        {
                            suma += i;
                        }
                    }
                    //Mostar el resultat de la suma
                    Console.WriteLine("La suma dels números des de 13 fins a " + numero + " és: " + suma);
                    break;

                case 2:
                    // Demanar a l'usuari un nombre
                    Console.WriteLine("Introdueix un nombre: ");
                    int num = Convert.ToInt32(Console.ReadLine());

                    // Inicialitzar les variables
                    int parells = 0, imparells = 0;
                    int sumaParells = 0, sumaImparells = 0;
                    int multiplesDe13 = 0;

                    // Recorregut de l'1 fins el número introduït
                    for (int i = 1; i <= num; i++)
                    {
                        if (i % 2 == 0) // Si el número es parell 
                        {
                            parells++;
                            sumaParells += i;
                        }

                        else // Si el número es imparell
                        {
                            imparells++;
                            sumaImparells += i;
                        }

                        if (i % 13 == 0) // Si es múltiple de 13
                        {
                            multiplesDe13++;
                        }
                    }

                    // Mostrar els resultats
                    Console.WriteLine("Números parells: " + parells);
                    Console.WriteLine("Números imparells: " + imparells);
                    Console.WriteLine("Suma de números parells: " + sumaParells);
                    Console.WriteLine("Suma de números imparells: " + sumaImparells);
                    Console.WriteLine("Múltples de 13 " + multiplesDe13);
                    break;

                case 3:
                    // Crear una instancia de la classe Random per generar jugades al atzar
                    Random random = new Random();

                    // Generar jugades per a cada jugador (valores aleatoris entre 0 i 2)
                    int jugador1 = random.Next(0, 3);
                    int jugador2 = random.Next(0, 3);

                    // Convertri les jugades numeriques a text
                    string jugada1 = TraduirJugada(jugador1);
                    string jugada2 = TraduirJugada(jugador2);

                    // Mostrar les jugades de cada jugador
                    Console.WriteLine($"Jugador 1 ha jugat: {jugada1}");
                    Console.WriteLine($"Jugador 2 ha jugat: {jugada2}");

                    // Determinar el guanyador o si es empat
                    string resultat = DeterminarGuanyador(jugador1, jugador2);
                    Console.WriteLine(resultat);

                    // Funcions per traduïr la jugada númerica a text
                    static string TraduirJugada(int jugada)
                    {
                        return jugada switch
                        {
                            0 => "pedra",
                            1 => "paper",
                            2 => "tisora",
                            _ => "jugada no vàlida"
                        };
                    }

                    // Funcions per determinar el guanyador
                    static string DeterminarGuanyador(int jugador1, int jugador2)
                    {
                        if (jugador1 == jugador2)
                        {
                            return "Empat!";
                        }
                        else if ((jugador1 == 0 && jugador2 == 2) || // pedra vence tisora
                                (jugador1 == 1 && jugador2 == 0) || // paper vence pedra
                                (jugador1 == 2 && jugador2 == 1))   // tisora vence paper
                        {
                            return "El guanyador és el Jugador 1!";
                        }
                        else
                        {
                            return "El guanyador és el Jugador 2!";
                        }
                    }
                    break;

                case 4:
                    // Saldo inicial
                    decimal saldo = 1000.00m;
                    bool continuar = true;

                    while (continuar)
                    {
                        Console.WriteLine("Benvingut al Caixer Automàtic!");
                        Console.WriteLine("1. Treure efectiu");
                        Console.WriteLine("2. Dipòsit");
                        Console.WriteLine("3. Consultar saldo");
                        Console.WriteLine("4. Sortir");
                        Console.Write("Selecciona una opció: ");
                        int opcio = Convert.ToInt32(Console.ReadLine());

                        switch (opcio)
                        {
                            case 1:
                                // Treure efectiu
                                Console.Write("Introdueix l'import que vols treure: ");
                                decimal retirar = Convert.ToDecimal(Console.ReadLine());

                                if (retirar > saldo)
                                {
                                    Console.WriteLine("Error: No pots retirar més del teu saldo disponible.");
                                }
                                else
                                {
                                    saldo -= retirar;
                                    Console.WriteLine($"Has retirat: {retirar}. Nou saldo: {saldo}");
                                }
                                break;

                            case 2:
                                // Dipòsit
                                Console.Write("Introdueix l'import que vols dipositar: ");
                                decimal diposit = Convert.ToDecimal(Console.ReadLine());
                                saldo += diposit;
                                Console.WriteLine($"Has dipositat: {diposit}. Nou saldo: {saldo}");
                                break;

                            case 3:
                                // Consultar saldo
                                Console.WriteLine($"El teu saldo actual és: {saldo}");
                                break;

                            case 4:
                                continuar = false;
                                Console.WriteLine("Gràcies per utilitzar el caixer automàtic. Fins aviat!");
                                break;

                            default:
                                Console.WriteLine("Opció no vàlida. Si us plau, intenta-ho de nou.");
                                break;
                        }
                    }
                    break;

                case 5:
                    // Demanar dades del client
                    Console.WriteLine("Quina es la teva edat? ");
                    int edat = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Introdueix els teus ingressos: ");
                    double ingressos = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Té una referencia del lloguer anterior positiva (Sí/No): ");
                    string referencia = (Console.ReadLine());

                    Console.WriteLine("Introdueix el número d'infraccions de transit greus registrades en els últims 5 anys: ");
                    int infraccions = Convert.ToInt32(Console.ReadLine());

                    //Comprovació de les condicions
                    bool potLlogar = ComprovarCondicions(edat, ingressos, referencia, infraccions);

                    if (potLlogar)
                    {
                        Console.WriteLine("El client pot llogar l'apartament ");
                    }
                    else
                    {
                        Console.WriteLine("El client no pot llogar l'apartament");
                    }
                    break; // Aquesta instrucció és correcta aquí, ja que tanquen el case

                    static bool ComprovarCondicions(int edat, double ingressos, string referencia, int infraccions)
                    {
                        {
                            // Condicions
                            bool condicioEdat = edat > 21 && edat < 65;
                            bool condicioIngressos = ingressos >= 2500;
                            bool condicioReferencia = referencia.ToLower() == "sí";
                            bool condicioInfraccions = infraccions <= 1;

                            // Retornar el resultat de totes les condicions
                            return condicioEdat && condicioIngressos && condicioReferencia && condicioInfraccions;
                        }
                    }
            }
        }
    }
}

