﻿using System;
using static System.Net.Mime.MediaTypeNames;

namespace Practica4
{
    class Program
    {
        static void Main(string[] args)
        {
            int queTriar;
            Console.WriteLine("Exercici a provar? 1 , 2 , 3 , 4");
            queTriar = Convert.ToInt32(Console.ReadLine());



            switch (queTriar)
            {
                case 1:
                    // Creem una llista per guardar els nombres aleatoris
                    int[] numeros = new int[55];
                    Random random = new Random();

                    // Generem 55 nombres aleatoris entre 2 i 1559
                    for (int i = 0; i < numeros.Length; i++)
                    {
                        numeros[i] = random.Next(2, 1560); // Next exclou el valor màxim, així que usem 1560 perquè inclogui també el número 1559
                    }

                    // Busquem el valor mínim i màxim a l'array
                    int valorMinim = numeros[0];
                    int valorMaxim = numeros[0];

                    foreach (int numero in numeros)
                    {
                        if (numero < valorMinim)
                        {
                            valorMinim = numero;
                        }
                        if (numero > valorMaxim)
                        {
                            valorMaxim = numero;
                        }
                    }

                    // Mostrem la llista de nombres, el valor mínim i el màxim
                    Console.WriteLine("Llista de nombres generats:");
                    Console.WriteLine(string.Join(", ", numeros));
                    Console.WriteLine("Valor mínim: " + valorMinim);
                    Console.WriteLine("Valor màxim: " + valorMaxim);
                    break;


                case 2:
                    // Creem una llista per guardar els nombres aleatoris
                    int[] numeross = new int[333];
                    Random randomm = new Random();

                    // Generem 333 nombres aleatoris entre 1 i 1000 (per exemple)
                    for (int i = 0; i < numeross.Length; i++)
                    {
                        numeross[i] = randomm.Next(1, 1000); // Aquesta línia genera nombres entre 1 i 1000
                    }

                    // Mitjana de tots els nombres de la llista
                    double mitjana = numeross.Average();
                    Console.WriteLine("Mitjana de tots els números: " + mitjana);

                    // 2. Comptar quants números són múltiples de 4
                    int multiplesDe4 = numeross.Count(n => n % 4 == 0);
                    Console.WriteLine("Números múltiples de 4: " + multiplesDe4);

                    // 3. Comptar quants números són múltiples d'11
                    int multiplesDe11 = numeross.Count(n => n % 11 == 0);
                    Console.WriteLine("Números múltiples de 11: " + multiplesDe11);

                    break;

                case 3:
                    // Demanar a l'usuari que introdueixi una frase
                    Console.WriteLine("Introdueix una frase:");
                    string frase = Console.ReadLine();

                    // Variables per comptar les vocals
                    int comptadorA = 0;
                    int comptadorE = 0;
                    int comptadorI = 0;
                    int comptadorO = 0;
                    int comptadorU = 0;

                    // Recorrem cada caràcter de la frase i comptem les vocals
                    foreach (char c in frase)
                    {
                        if (c == 'a') comptadorA++;
                        else if (c == 'e') comptadorE++;
                        else if (c == 'i') comptadorI++;
                        else if (c == 'o') comptadorO++;
                        else if (c == 'u') comptadorU++;
                    }

                    // Mostrem el resultat
                    Console.WriteLine("Nombre de vocals en la frase:");
                    Console.WriteLine("a: " + comptadorA);
                    Console.WriteLine("e: " + comptadorE);
                    Console.WriteLine("i: " + comptadorI);
                    Console.WriteLine("o: " + comptadorO);
                    Console.WriteLine("u: " + comptadorU);

                    break;

                case 4:
                    // Saldo inicial
                    decimal saldo = 1000.00m;
                    bool continuar = true;

                    while (continuar)
                    {
                        Console.WriteLine("Benvingut al Caixer Automàtic!");
                        Console.WriteLine("1. Treure efectiu");
                        Console.WriteLine("2. Dipòsit");
                        Console.WriteLine("3. Consultar saldo");
                        Console.WriteLine("4. Sortir");
                        Console.Write("Selecciona una opció: ");

                        if (int.TryParse(Console.ReadLine(), out int opcio))
                        {
                            switch (opcio)
                            {
                                case 1:
                                    RetirarEfectiu(ref saldo);
                                    break;

                                case 2:
                                    Dipositar(ref saldo);
                                    break;

                                case 3:
                                    ConsultarSaldo(saldo);
                                    break;

                                case 4:
                                    continuar = false;
                                    Console.WriteLine("Gràcies per utilitzar el caixer automàtic. Fins aviat!");
                                    break;

                                default:
                                    Console.WriteLine("Opció no vàlida. Si us plau, intenta-ho de nou.");
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Introdueix una opció vàlida.");
                        }
                    }
                    break;

                default:
                    Console.WriteLine("Opció no vàlida. Si us plau, selecciona entre 1 i 4.");
                    break;
            }
        }

        // Funcions
        static void RetirarEfectiu(ref decimal saldo)
        {
            Console.Write("Introdueix l'import que vols treure: ");
            if (decimal.TryParse(Console.ReadLine(), out decimal retirar) && retirar > 0)
            {
                if (retirar > saldo)
                {
                    Console.WriteLine("Error: No pots retirar més del teu saldo disponible.");
                }
                else
                {
                    saldo -= retirar;
                    Console.WriteLine($"Has retirat: {retirar}. Nou saldo: {saldo}");
                }
            }
            else
            {
                Console.WriteLine("Introdueix un import vàlid.");
            }
        }

        static void Dipositar(ref decimal saldo)
        {
            Console.Write("Introdueix l'import que vols dipositar: ");
            if (decimal.TryParse(Console.ReadLine(), out decimal diposit) && diposit > 0)
            {
                saldo += diposit;
                Console.WriteLine($"Has dipositat: {diposit}. Nou saldo: {saldo}");
            }
            else
            {
                Console.WriteLine("Introdueix un import vàlid.");
            }
        }

        static void ConsultarSaldo(decimal saldo)
        {
            Console.WriteLine($"El teu saldo actual és: {saldo}");
        }
    }
}


