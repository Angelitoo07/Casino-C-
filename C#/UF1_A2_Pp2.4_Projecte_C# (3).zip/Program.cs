﻿using System;
using System.Data;
using System.Runtime.CompilerServices;
using System.Threading;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Projecte
{
    class Program
    {
        static void Main(string[] args)
        {
            // Titol CASINO amb colors
            Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
            Console.WriteLine("########     #########       #########       ##      ####     ##     #########"); // Aquesta linia es part de les lletres del títol
            Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
            Console.WriteLine("########     #########       #########       ##      ####     ##     #########"); // Aquesta linia es part de les lletres del títol
            Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
            Console.WriteLine("##           ##     ##       ##                      ## ##    ##     ##     ##"); // Aquesta linia es part de les lletres del títol
            Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
            Console.WriteLine("##           ##     ##       #########       ##      ##  ##   ##     ##     ##"); // Aquesta linia es part de les lletres del títol
            Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
            Console.WriteLine("##           #########       #########       ##      ##   ##  ##     ##     ##"); // Aquesta linia es part de les lletres del títol
            Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
            Console.WriteLine("##           #########              ##       ##      ##    ## ##     ##     ##"); // Aquesta linia es part de les lletres del títol
            Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
            Console.WriteLine("#######      ##     ##       #########       ##      ##     ####     #########"); // Aquesta linia es part de les lletres del títol
            Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
            Console.WriteLine("#######      ##     ##       #########       ##      ##      ###     #########\r\n"); // Aquesta linia es part de les lletres del títol
            Console.ResetColor();
            Console.WriteLine("Escriu la quantitat de diners que vols afegir per a el teu saldo: "); // Demanar al client la quantitat de diners que vol afegir al seu saldo

            double saldoGeneral = Convert.ToDouble(Console.ReadLine()); // Inicialitzar el saldoGeneral
            while (true)
            {
                int queTriar;
                // Diseny del text per demanar quin joc vol jugar
                Console.WriteLine("+-----------------------------+");
                Console.WriteLine("|     Opcions de Joc          |");
                Console.WriteLine("+-----------------------------*");
                Console.WriteLine("|  1. Màquina escurabutxaques |");
                Console.WriteLine("|  2. Ruleta                  |");
                Console.WriteLine("|  3. Curses de cavalls       |");
                Console.WriteLine("+-----------------------------+");

                queTriar = Convert.ToInt32(Console.ReadLine()); // Inicialitzar la llista per escollir el joc
                switch (queTriar)
                {
                    case 1: // Màquina escurabutxaques
                        // Limpiar consola
                        Console.Clear();

                        // Titol CASINO amb colors
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("########     #########       #########       ##      ####     ##     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("########     #########       #########       ##      ####     ##     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("##           ##     ##       ##                      ## ##    ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("##           ##     ##       #########       ##      ##  ##   ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("##           #########       #########       ##      ##   ##  ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("##           #########              ##       ##      ##    ## ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("#######      ##     ##       #########       ##      ##     ####     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("#######      ##     ##       #########       ##      ##      ###     #########\r\n"); // Aquesta linia es part de les lletres del títol
                        Console.ResetColor();

                        // Inicialitzar
                        double aposta;

                        // Sol·licitar la quantitat d'aposta
                        Console.WriteLine($"Quant vols apostar? (Saldo disponible: {saldoGeneral}$)."); // Demanar a l'usuari quant vol apostar
                        aposta = Convert.ToDouble(Console.ReadLine());

                        // Benvinguda
                        Console.WriteLine("\r\nBenvingut a la Escurabutxaques!\r\n"); // Benvinguda a l'escurabutxaques


                        // Saldo inicial
                        Console.WriteLine($"Aquesta es la teva aposta {aposta}"); // Mostrar en pantalla l'aposta de l'usuari
                        Random random = new Random();

                        Console.WriteLine($"Saldo inicial: {saldoGeneral}$."); // Mostrar en pantalla el saldo general de l'usuari
                        Console.WriteLine("Pressiona qualsevol tecla per començar...\r\n"); // Mostrar en pantalla el missatge a l'usuari dient-li que fagi clic a qualsevol tecla del teclat per començar

                        while (saldoGeneral >= aposta)
                        {
                            Console.Write("\nVols jugar? (Presiona Enter per a jugar o escriu 'S' per a sortir): ");
                            string input = Console.ReadLine();

                            if (input == "S")
                            {
                                Console.WriteLine("Gràcies per jugar. ¡Adéu!");
                                break;
                            }


                            // Descomptar el cost per jugada
                            saldoGeneral -= aposta;

                            // Girar els rodets
                            Console.WriteLine("\nGirant els rodets...");
                            Thread.Sleep(3000);

                            // Generar tres símbols aleatoris
                            int simbolo1 = random.Next(1, 6); // Nombre entre 1 y 5
                            int simbolo2 = random.Next(1, 6);
                            int simbolo3 = random.Next(1, 6);

                            Console.WriteLine($"Resultat: [·{simbolo1}·] [·{simbolo2}·] [·{simbolo3}·]");

                            // Comprovar si guanya
                            if (simbolo1 == simbolo2 && simbolo2 == simbolo3)
                            {
                                Console.Beep(1000, 500); // So al guanyar
                                saldoGeneral = saldoGeneral + aposta * 3;
                                Console.ForegroundColor = ConsoleColor.Green; // Color verd al guanyar
                                Console.WriteLine($"Felicitats! Has guanyat {aposta * 3}$ El teu saldo actual es {saldoGeneral}$");
                                Console.ResetColor(); // Treure el color verd
                            }

                            else if (simbolo1 == simbolo2 || simbolo1 == simbolo3 || simbolo2 == simbolo3)
                            {
                                Console.Beep(1000, 500); // So al guanyar
                                saldoGeneral = saldoGeneral + aposta * 2;
                                Console.ForegroundColor = ConsoleColor.Green; // Color verd al guanyar
                                Console.WriteLine($"Felicitats! Has guanyat {aposta * 2}$ El teu saldo actual es {saldoGeneral}$");
                                Console.ResetColor(); // Treure el color verd
                            }

                            else
                            {
                                Console.Beep(500, 500);  // So al perdre
                                Console.ForegroundColor = ConsoleColor.Red; // Color vermell al perdre
                                saldoGeneral = saldoGeneral- aposta;
                                Console.WriteLine($"No has guanyat aquesta vegada. Saldo restant {saldoGeneral} ¡Seguiex intentant!");
                                Console.ResetColor(); // Treure el color vermell
                            }

                            // Verificar si queda saldo suficient per continuar
                            if (saldoGeneral < aposta)
                            {
                                Console.WriteLine("No tens suficient saldo per a continuar. Gràcies per jugar!");
                                break;
                            }
                        }

                        Console.WriteLine("Fi del joc. ¡Fins aviat!");

                        break;

                    case 2: // Ruleta
                        // Limpiar consola
                        Console.Clear();

                        // Titol CASINO amb colors
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("########     #########       #########       ##      ####     ##     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("########     #########       #########       ##      ####     ##     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("##           ##     ##       ##                      ## ##    ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("##           ##     ##       #########       ##      ##  ##   ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("##           #########       #########       ##      ##   ##  ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("##           #########              ##       ##      ##    ## ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("#######      ##     ##       #########       ##      ##     ####     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("#######      ##     ##       #########       ##      ##      ###     #########\r\n"); // Aquesta linia es part de les lletres del títol
                        Console.ResetColor();

                        // Inicialitzar
                        bool continuarRuleta = true;
                        Random randomRuleta = new Random();


                        Console.WriteLine($"Saldo inicial: {saldoGeneral}$");

                        List<int> list = new List<int>();
                        List<int[]> list2 = new List<int[]>();
                        Console.WriteLine("Escriu a que vols apostar...\r\n");
                        Console.WriteLine("              -----------------------------------------------------------------------------");
                        Console.WriteLine($"            |      | 3 | 6 | 9 | 12 | 15 | 18 | 21 | 24 | 27 | 30 | 33 | 36 | {37}. 2 a 1 |");
                        Console.WriteLine("            |       -----------------------------------------------------------------------");
                        Console.WriteLine($"          [    0   | 2 | 5 | 8 | 11 | 14 | 17 | 20 | 23 | 26 | 29 | 32 | 35 | {38}. 2 a 1 |");
                        Console.WriteLine("            |       -----------------------------------------------------------------------");
                        Console.WriteLine($"            |      | 1 | 4 | 7 | 10 | 13 | 16 | 19 | 22 | 25 | 28 | 31 | 34 | {39}. 2 a 1 |");
                        Console.WriteLine("              -----------------------------------------------------------------------------");
                        Console.WriteLine($"                   | {40}. 1rs 12   |   {41}. 2ns 12    |   {42}. 3rs 12    |");
                        Console.WriteLine("                    -----------------------------------------------------------------------------------");
                        Console.WriteLine($"                   | {43}. 1 a 8 | {44}. EVEN  | {45}. Red | {46}. Black | {47}. ODD | {48}. 19 a 36 |");
                        Console.WriteLine("                    -----------------------------------------------------------------------------------");
                        while (continuarRuleta && saldoGeneral > 0)
                        {
                            // Sol·licitar la quantitat d'aposta
                            Console.WriteLine("\nEscriu la teva aposta (o escriu '0' per sortir): ");
                            double apostaRuleta = Convert.ToDouble(Console.ReadLine());

                            if (apostaRuleta == 0)
                            {
                                Console.WriteLine("Gràcies per jugar ¡Fins la pròxima!");
                                break;
                            }

                            if (apostaRuleta > saldoGeneral)
                            {
                                Console.WriteLine("No pots apostar més del que tens. Intenta-ho de nou!");
                                continue;
                            }

                            Console.WriteLine("Selecciona un número (0-36 per apostar a un número en concret o 37-47 per apostar a alguna aposta especial):");
                            int eleccio = Convert.ToInt32(Console.ReadLine());

                            if (eleccio < 0 || eleccio > 48)
                            {
                                Console.WriteLine("Número invàlid. Seleccioneu un número entre 0 i 47.");
                                continue;
                            }

                            // Gira la ruleta
                            int resultat = randomRuleta.Next(0, 37); // Número aleatorio entre 0 y 36
                            Console.WriteLine($"La ruleta ha caigut en el número: {resultat}");

                            bool guanya = false;

                            // Gestió de resultats
                            if (eleccio >= 0 && eleccio <= 36)
                            {
                                guanya = (eleccio == resultat);
                            }

                            else
                            {
                                // Apostes especials
                                switch (eleccio)
                                {
                                    case 37: // Primera columna
                                        guanya = (resultat % 3 == 1);
                                        break;

                                    case 38: // Segona columna
                                        guanya = (resultat % 3 == 2);
                                        break;

                                    case 39: // Tercera columna
                                        guanya = (resultat % 3 == 0 && resultat != 0);
                                        break;

                                    case 40: // Primers 12
                                        guanya = (resultat >= 1 && resultat <= 12);
                                        break;

                                    case 41: // Segons 12
                                        guanya = (resultat >= 13 && resultat <= 24);
                                        break;

                                    case 42: // Tercers 12
                                        guanya = (resultat >= 25 && resultat <= 36);
                                        break;

                                    case 43: // De 1 a 8
                                        guanya = (resultat >= 1 && resultat <= 8);
                                        break;

                                    case 44: // Parells o també es pot dir EVEN (en anglès)
                                        guanya = (resultat != 0 && resultat % 2 == 0);
                                        break;

                                    case 45: // Números vermells
                                        guanya = new int[] { 1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36 }.Contains(resultat);
                                        break;

                                    case 46: // Números negres
                                        guanya = new int[] { 2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35 }.Contains(resultat);
                                        break;

                                    case 47: // Imparells o també es pot dir ODD (en anglès)
                                        guanya = (resultat % 2 == 1);
                                        break;


                                    case 48: // De 19 a 36
                                        guanya = (resultat >= 19 && resultat <= 36);
                                        break;


                                }
                            }

                            // Calcul de guanys
                            if (guanya)
                            {
                                double multiplicador = (eleccio >= 37) ? 2 : 35;
                                double guany = apostaRuleta * multiplicador;
                                saldoGeneral += guany;
                                Console.Beep(1000, 500); // So al guanyar
                                Console.ForegroundColor = ConsoleColor.Green; // Color verd al guanyar
                                Console.WriteLine($"¡Felicitats! Has guanyat {guany}$! El teu saldo actual és {saldoGeneral}$.");
                                Console.ResetColor(); // Treure el color verd
                            }

                            else
                            {
                                saldoGeneral -= apostaRuleta;
                                Console.Beep(500, 500);  // So al perdre
                                Console.ForegroundColor = ConsoleColor.Red; // Color vermell al guanyar
                                Console.WriteLine($"Has perdut {apostaRuleta}$. El teu saldo actual és {saldoGeneral}$.");
                                Console.ResetColor(); // Treure el color vermell
                            }

                            if (saldoGeneral <= 0)
                            {
                                Console.WriteLine("T'has quedat sense saldo. ¡Gràcies per jugar!");
                                continuarRuleta = false;
                            }
                        }

                        break;

                    case 3: // Cursa de Cavalls
                        // Limpiar consola
                        Console.Clear();

                        // Titol CASINO amb colors
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("########     #########       #########       ##      ####     ##     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("########     #########       #########       ##      ####     ##     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("##           ##     ##       ##                      ## ##    ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("##           ##     ##       #########       ##      ##  ##   ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("##           #########       #########       ##      ##   ##  ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("##           #########              ##       ##      ##    ## ##     ##     ##"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Red; // Aquesta linía posarà la següent linia de codi en color vermell
                        Console.WriteLine("#######      ##     ##       #########       ##      ##     ####     #########"); // Aquesta linia es part de les lletres del títol
                        Console.ForegroundColor = ConsoleColor.Green; // Aquesta linía posarà la següent linia de codi en color verd
                        Console.WriteLine("#######      ##     ##       #########       ##      ##      ###     #########\r\n"); // Aquesta linia es part de les lletres del títol
                        Console.ResetColor();

                        // Inicialitzar
                        double aposta3;

                        // Sol·licitar la quantitat a apostar
                        while (true)
                        {
                            Console.WriteLine($"Quant desitges apostar? (Saldo disponible: {saldoGeneral}$)");
                            if (double.TryParse(Console.ReadLine(), out aposta3) && aposta3 > 0 && aposta3 <= saldoGeneral)
                            {
                                break; // Sortir del bucle si l'entrada es valida
                            }
                            Console.WriteLine("Entrada no vàlida. Introdueix una aposta vàlida:");
                        }

                        // Saldo inicial
                        Console.WriteLine(saldoGeneral);
                        Console.WriteLine(aposta3);
                        Random randomCavalls = new Random();

                        Console.WriteLine("Benvingut a la Curses de Cavalls!\r\n");
                        Console.WriteLine($"Saldo inicial: {saldoGeneral}$");

                        // Mostrar misatge per a escullir cavall
                        Console.WriteLine("\nEscull un cavall per apostar (1-5): ");
                        int cavallEscollit;
                        while (true)
                        {
                            if (int.TryParse(Console.ReadLine(), out cavallEscollit) && cavallEscollit >= 1 && cavallEscollit <= 5)
                            {
                                break; // Sortir del bucle si l'entrada es valida
                            }
                            Console.WriteLine("Entrada no vàlida. Escull un cavall entre 1 i 5.");
                        }

                        Console.WriteLine("\nLa cursa comença ja!");
                        int cavallGuanyador = randomCavalls.Next(1, 6);
                        Console.WriteLine($"El cavall guanyador es el número {cavallGuanyador}");

                        // Determinar resultat
                        if (cavallEscollit == cavallGuanyador)
                        {
                            double premi = aposta3 * 5; // Pagament per guanyar es el triple de la aposta
                            saldoGeneral += premi;
                            Console.Beep(1000, 500); // So al guanyar
                            Console.ForegroundColor = ConsoleColor.Green; // Color verd al guanyar
                            Console.WriteLine($"¡Felicitats! Has guanyat {premi}$! Ara el teu saldo és: {saldoGeneral}$.");
                            Console.ResetColor(); // Treure el color verd
                        }
                        else
                        {
                            saldoGeneral -= aposta3;
                            Console.Beep(500, 500);  // So al perdre
                            Console.ForegroundColor = ConsoleColor.Red; // Color vermell al guanyar
                            Console.WriteLine($"Has perdut {aposta3}$. Ara el teu saldo és: {saldoGeneral}$.");
                            Console.ResetColor(); // Treure el color vermell
                        }

                        // Verificar si queda saldo
                        if (saldoGeneral <= 0)
                        {
                            Console.WriteLine("\nT'has quedat sense saldo. Gràcies per jugar. ¡Torna aviat!");
                            return; // Sortir completament del programa
                        }

                        // Preguntar si desitja jugar una altre vegada
                        Console.WriteLine("¿Vols jugar una altra vegada? (s/n)");
                        string resposta = Console.ReadLine().ToLower();
                        if (resposta != "s")
                        {
                            Console.WriteLine("Gràcies per jugar. ¡Fins aviat!");
                            return; // Soritr completament del programa
                        }

                        break; // Sortir del case 3

                }
            }
        }
    }
}


